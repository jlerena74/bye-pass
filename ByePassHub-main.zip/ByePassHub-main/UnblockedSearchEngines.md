# ByePassHub > Private Search Engines
## If you like these lists, make sure to star this repository!
This files includes links of **private search engines,** which you can **search ANYTHING** on the web untracked, unrestricted, and free, but you cannot go to websites unlike proxies. <br> 
<br>

 ---
 
 ### Other files:
**Exploits, Bypasses, Bookmarklets:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/Exploits/README.md) <br>
**Unblockers:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/mainUnblockers.md) or go to the mainUnblockers.md file. <br>
**Main Games:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/Games.md) or to the games.md file<br>
**Kahoot, Gimkit, Blooket (and more) Cheats:** Go [here](https://github.com/wea-f/ByePassHub//blob/main/Cheats.md) or go to the Cheats.md file. <br>
**Making your own unblocker link:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/MakeYourOwnLink.md) or go to the MakeYourOwnLink.md file. <br>
**Movies and Anime:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/Movies%26Anime.md) or to the movies&anime.md file <br> <br>
**Back to Main Hub:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/README.md) or go to the main README.md file <br>

---

### Brave:
https://search.brave.com/ <br>

### Ghostly:
https://ghosterysearch.com/ <br>

### Ecosia:
https://ecosia.org/ <br>

### Searx:
https://searx.thegpm.org/ <br>

### MetaGer:
https://metager.org/ <br>

### Mojeek:
https://www.mojeek.com/ <br>

### Disconnect:
https://search.disconnect.me/ <br>

### OneSearch:
https://www.onesearch.com/ <br>

### Dogpile:
https://www.dogpile.com/texis/search <br>

### Wiki:
https://wiki.com/ <br>

### Boardreader:
https://boardreader.com/ <br>

### Searchcode:
https://searchcode.com/ <br>

### LocaBrowser:
https://www.locabrowser.com/ <br>

### Carrot2:
https://search.carrot2.org/#/search/web <br>

### Infospace:
https://www.infospace.com/ <br>

### AIO Search:
https://www.aiosearch.com/ <br>

### Entire web:
https://www.entireweb.com/#google_vignette <br>

### MetaGear:
https://metager.org/ <br>

### ActiveSearchResults:
https://www.activesearchresults.com/  <br>

### MetaCrawler:
https://www.metacrawler.com/ <br>

### Wolfram Alpha:
https://www.wolframalpha.com/ <br>

### Kagi:
Sign up needed. <br>
https://kagi.com/ <br>
### Ask:
https://www.ask.com/ <br>
### YaCy:
https://yacy.searchlab.eu/index.html <br>

### Symbaloo:
https://www.symbaloo.com/search?q <br>
