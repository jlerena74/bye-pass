# ByePassHub > Movies & Anime | updated June 7
## If you like this list, make sure to star it!
### This is a collection of links of movies and anime watchers **free**! 
**Exploits, Bypasses, Bookmarklest:** Go [here](https://github.com/wea-f/ByePassHub/tree/main/Exploits) or go to the Exploits folder. <br>
**Main Games:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/Games.md) <br>
**Unblockers:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/mainUnblockers.md) or go to the mainUnblockers.md file <br>
**Kahoot, Gimkit, Blooket (and more) Cheats:** Go [here](https://github.com/wea-f/ByePassHub//blob/main/Cheats.md) or go to the Cheats.md file. <br>
**Making your own unblocker link:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/MakeYourOwnLink.md) or go to the MakeYourOwnLink.md file. <br>
**Main Hub:** Go [here](https://github.com/wea-f/ByePassHub/blob/main/README.md) or go to the main README.md file <br>

### Be sure to scroll all the way down for ALL links. 
  #### here is an [url opener](https://www.openallurls.com/) to save some time.
  #### Use a proxy if site is blocked.
---

## Movies
### MovieWeb
https://watchflix.app/   <br>
https://teamberga.xyz/ <br>
https://scootydooter.vercel.app/   <br>
https://movie-web-lac-six.vercel.app/ <br>
https://movie-web-xlta.vercel.app/ <br>
https://ephemeral-cheesecake-17073d.netlify.app/ <br>
https://dashing-starship-280785.netlify.app/ <br>
https://admirable-kitten-4405b5.netlify.app/ <br>
https://dashing-starship-280785.netlify.app/  <br>
https://majinitx12.github.io/#/search/movie <br>
https://ephemeral-cheesecake-17073d.netlify.app/ <br>
https://movie-web-me.vercel.app/#/search/movie<br>
https://movie-web-meta-refactor.vercel.app/#/search/movie <br>
https://movie-web.us/#/search/movie <br>
### Movie Services using Google Slides
Netflix: https://docs.google.com/presentation/d/149GpUX0v2xNpwbUTv0Ra1bXSBJ8VImN3yQXMYA9ZhKA/edit <br>
Disney+: https://docs.google.com/presentation/d/1cqMoS7rNvOX77938GusdWNi6mYVPOfETCVsAVW9I9ps/edit <br>
Hulu: https://docs.google.com/presentation/d/1YDZCGRJMcIXA6CDnnxEUcNuZuEx-NdUETeeVFulhYDg/edit <br>
### Other Movie Sites
https://onionplay.se/ <br>
https://serieshd.watch/ <br>
https://movie4kto.net/  <br>
**prob unblocked** https://sites.google.com/view/sealflix <br>
https://flixwave.to/  <br>
https://shuttletv.net/ <br>
https://movieshd.watch/ <br>
https://movie4kto.net/ <br>
https://serieshd.watch/ <br>
https://soap2dayhd.com/  <br>
https://freemoviesfull.cc/ <br>
https://freemovieswatch.tv/  <br>
https://watchfreemovi.es/  <br>
https://flixhd.cc/  <br>
https://quitt.net/ <br>
https://tikmovies.com/ <br>
<br>
### Movie Recordings
Spongebob Squarepants movie: https://drive.google.com/file/d/1-bYIrWe0duy7IT8p2z0JKIA9sYrSRO8L/view?usp=drive_link <br>
Sing 1: https://drive.google.com/file/d/1-J7v3NOfQxngx50U66dELoa5P17m2xDP/view <br>
Sing 2: https://drive.google.com/file/d/1uqHaBulJOC3wjc1gnotbY__QrMcDr7Tz/view <br>
Inside Out: https://drive.google.com/file/d/1DRTfnpCiVdPzwsWMKqQndMnTgxlyACXW/view <br>
There are so many more in this doc: https://docs.google.com/document/d/1Ed0x9WpogjRGzER_5lUqI807QS0MEuDM31OFnRs8a-A/edit#heading=h.ypawngwfb7l9 <br>
## Shows
Spongebob Seasons 1-14: https://drive.google.com/drive/folders/1cOFMumtLFERJqS6Y5oTyBb6ZRXNHCgZF?usp=drive_link <br>
Family Guy 1-22 seasons: https://drive.google.com/drive/folders/11W6C-Jqv9iQVasqjfiaYz77puax1UTjH?usp=drive_link <br>
South Park full series: https://drive.google.com/drive/folders/1PzKaoaK4blzlaoxnwC20gZoeYE5mDxWL?usp=drive_link <br>
Rick and Morty: https://drive.google.com/drive/folders/17ODzdQoYZZxX6ANHFLo0tD1UIkllvCui?usp=drive_link <br>
Pokemon: https://drive.google.com/drive/folders/1I7-ZUInlg9jb4R6LGq0qX3n7bjGKPFFO?usp=drive_link <br>
The Simpsons: https://drive.google.com/drive/folders/1ZtFBjPAE-qVzdHJ3EKnvlBFNhux5m3Hi?usp=drive_link <br>


## Anime
https://anix.to/ <br>
https://kaido.to/  <br>
https://animeflix.live/ <br>
https://moopa.live/ <br> 
### Demonslayer Season 1 (Ep 1-6)
https://drive.google.com/file/d/16ApJR3QbXonfkNXPNmt2gWj6n24-0PaO/view <br>
https://drive.google.com/file/d/1fK6TzSyBqeQH0YiHOj2dubiv-lc0FRfS/view <br>
https://drive.google.com/file/d/1fK6TzSyBqeQH0YiHOj2dubiv-lc0FRfS/view <br>
https://drive.google.com/file/d/1N8wIzuscxJWkLG9UQbFPldazlqHv96Tm/view <br>
https://drive.google.com/file/d/18RaZN2O_HxnLVcAsHAF7vUuOV3EKaClJ/view <br>
https://drive.google.com/file/d/1WSSewkcYjggHl_cPo2gV-vxnX9MK0bZL/view <br>

<br> <br>

#### Credits:
Most from proxies 100+ and genesis hyperspace documents.
